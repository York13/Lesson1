package Data;

public interface PersonRepository {

    PersonalData getPersonalData();
}
