package Data;

public interface PersonPropertyKeys {
    String FIO = "FIO";
    String DOB = "DOB";
    String PHONE = "phone";
    String EMAIL = "email";
    String SKYPE = "skype";
    String AVATAR = "avatar";
    String TARGET = "target";
    String EXPERIENCES = "experiences";
    String EDUCATIONS = "educations";
    String ADDITIONAL_EDUCATIONS = "additional_educations";
    String SKILLS = "skills";
    String EXAMPLES_CODE = "examples_code";
}
