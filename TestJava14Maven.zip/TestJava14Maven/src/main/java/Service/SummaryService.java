package Service;

public interface SummaryService {

    void createHtmlFile(String Path);
}
